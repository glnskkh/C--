#include <iostream>

int main()
{
  std::cout << (float)0.1 + (float)0.2 << std::endl;
}