function User(name, age) {
  this.name = name;
  this.age = age;
}

User.type = "Human";

User.prototype.getAge = function () { return this.age };

let u1 = new User("a", 1);

console.log(u1.age, u1.getAge());